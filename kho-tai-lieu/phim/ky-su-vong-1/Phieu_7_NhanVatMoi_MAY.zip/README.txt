PHIẾU NHÂN VẬT MỚI — MÙA KÝ SỰ TỔNG QUÁT "GIỌT NƯỚC TÍ PHIÊU LƯU KHẮP THẾ GIỚI"
Người vẽ: Mây — Bản NHÁP theo mô tả khoá sơ bộ trong Bảng phân công (chốt lại sau khi có phác họa của Kill)
Ngày: 24/11/2026

ĐỦ BỘ 14/14 ẢNH (7 nhân vật × 2 ảnh: turnaround 3 góc + biểu cảm 4 ô):

01_RuaBien_Turnaround.png / 02_RuaBien_BieuCam.png
  Rùa Biển con (Biển): mai xanh ô-liu hoa văn sóng nước, mắt hiền, vòng san hô đỏ ở cổ.
03_Khi_Turnaround.png / 04_Khi_BieuCam.png
  Khỉ con (Rừng mưa): lông nâu vàng, đuôi dài, tai to, túi lá đựng trái cây đeo hông.
05_NguaVan_Turnaround.png / 06_NguaVan_BieuCam.png
  Ngựa vằn con (Đồng cỏ): sọc đen trắng khắp thân, bờm sọc dựng đứng.
07_SonDuong_Turnaround.png / 08_SonDuong_BieuCam.png
  Sơn Dương con (Đồi núi): sừng cong nhỏ, lông xám nâu, khăn len đỏ.
09_LacDa_Turnaround.png / 10_LacDa_BieuCam.png
  Lạc Đà con (Sa mạc): một bướu màu cát, lông mi dài hai hàng, chuông đồng nhỏ ở cổ.
11_CanhCut_Turnaround.png / 12_CanhCut_BieuCam.png
  Chim Cánh Cụt con (Băng giá): cánh cụt hoàng đế con lông xám bông, bụng trắng, khăn quàng xanh biển.

Phong cách chung: 3D như Mùa 1 — mắt to tròn, má hồng, dễ thương; nền xám sáng trung tính; không chữ.
Mỗi ảnh biểu cảm gồm 4 ô: vui cười / ngạc nhiên / buồn rưng rưng / quyết tâm.

13_CaNho_Turnaround.png / 14_CaNho_BieuCam.png
  Cá Nhỏ (Biển) — theo MÔ TẢ KHOÁ MỚI thầy và Đạo diễn chốt 24/11 (thay bản cá hề cam ban đầu):
  cá hề hồng (pink skunk clownfish): thân nhỏ nhắn màu hồng đào trong mờ, MỘT sọc trắng mảnh
  chạy dọc sống lưng từ đầu tới đuôi, một vạch trắng mảnh sau mắt, viền vây màu trắng,
  vây hồng nhạt, mắt đen tròn long lanh, má ửng hồng, vẻ nhanh nhẹn tinh nghịch.
  TUYỆT ĐỐI không thân cam, không sọc trắng ngang dày.
